from .generator import gerar_mensagem_commit

def main():
    print(gerar_mensagem_commit())
